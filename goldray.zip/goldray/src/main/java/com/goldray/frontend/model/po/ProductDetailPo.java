package com.goldray.frontend.model.po;

/**
 * Created by zwb on 2017/4/20.
 */
public class ProductDetailPo {
    private String code;
    private String title;
    private String introduction;
    private String path;
    private String coverImgName;
    private String firstImgName;
    private String secondImgName;
    private String thirdImgName;
    private String text;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getIntroduction() {
        return introduction;
    }

    public void setIntroduction(String introduction) {
        this.introduction = introduction;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getCoverImgName() {
        return coverImgName;
    }

    public void setCoverImgName(String coverImgName) {
        this.coverImgName = coverImgName;
    }

    public String getFirstImgName() {
        return firstImgName;
    }

    public void setFirstImgName(String firstImgName) {
        this.firstImgName = firstImgName;
    }

    public String getSecondImgName() {
        return secondImgName;
    }

    public void setSecondImgName(String secondImgName) {
        this.secondImgName = secondImgName;
    }

    public String getThirdImgName() {
        return thirdImgName;
    }

    public void setThirdImgName(String thirdImgName) {
        this.thirdImgName = thirdImgName;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}
