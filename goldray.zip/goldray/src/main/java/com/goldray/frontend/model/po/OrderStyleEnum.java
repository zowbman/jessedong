package com.goldray.frontend.model.po;

/**
 * Created by zwb on 2017/4/20.排序枚举
 */
public enum OrderStyleEnum {
    ACS, DESC;
}