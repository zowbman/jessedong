package com.goldray.frontend.model.po;

/**
 * Created by zwb on 2017/4/20.
 */
public class TopNews {
    private int id;
    private String title;
    private String resume;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getResume() {
        return resume;
    }

    public void setResume(String resume) {
        this.resume = resume;
    }
}
