package com.goldray.frontend.model.po;

/**
 * Created by zwb on 2017/4/20.
 */
public class RichTextPo {
    private String text;

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}
