package com.goldray.frontend.model.po;

/**
 * Created by zwb on 2017/4/20.
 */
public class NewsPo {
    private String title;
    private String text;
    private int addTime;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public int getAddTime() {
        return addTime;
    }

    public void setAddTime(int addTime) {
        this.addTime = addTime;
    }
}
