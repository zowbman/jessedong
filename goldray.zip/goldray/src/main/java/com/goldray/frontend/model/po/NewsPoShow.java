package com.goldray.frontend.model.po;

/**
 * Created by zwb on 2017/4/20.
 */
public class NewsPoShow {
    private String title;
    private String text;
    private String addTime;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getAddTime() {
        return addTime;
    }

    public void setAddTime(String addTime) {
        this.addTime = addTime;
    }
}
