package com.goldray.helper;

/**
 * Created by zwb on 2016/12/5.
 */
public class CodeHelper {
    public static final int SUCCESS = 0;
    public static final int FAILURE = 1;
    public static final int PARAMS_ERROR = 1001;
    public static final int SERVER_ERROR = 1002;
    public static final int NEWSNOTEXIST_ERROR = 1003;
    public static final int USERNAMEORPWDERROR = 1004;
    public static final int AJAXNOPRIVILEGE = 1005;
}
